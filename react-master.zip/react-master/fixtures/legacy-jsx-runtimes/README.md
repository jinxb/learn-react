# Legacy JSX Runtimes

This is an internal testing fixture for the special JSX runtime versions released for 0.14, 15, and 16.

They are checked into the corresponding `react-*/cjs/*` folders.

Run the full regression suite:

```
yarn
yarn test
```
